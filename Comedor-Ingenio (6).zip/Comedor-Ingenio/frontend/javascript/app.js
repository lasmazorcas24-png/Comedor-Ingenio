// Comedor Ingenio · Fase 1: acceso, cambio de PIN e inicio provisional por rol.
(function () {
  'use strict';
  const app = document.getElementById('app');
  const toast = document.getElementById('aviso');
  let usuario = null;      // perfil devuelto por la API
  let pinTemporal = null;  // solo en memoria, para el cambio obligatorio de PIN
  let tabActiva = 0;

  /* ---------- utilidades ---------- */
  function h(tag, props) {
    const el = document.createElement(tag);
    Object.keys(props || {}).forEach(function (k) {
      const v = props[k];
      if (k === 'class') el.className = v;
      else if (k.indexOf('on') === 0) el.addEventListener(k.slice(2), v);
      else if (v === true) el.setAttribute(k, '');
      else if (v !== false && v != null) el.setAttribute(k, v);
    });
    Array.prototype.slice.call(arguments, 2).forEach(function agregar(c) {
      if (c == null || c === false) return;
      if (Array.isArray(c)) return c.forEach(agregar);
      el.append(typeof c === 'object' ? c : String(c));
    });
    return el;
  }

  let temporizador = null;
  function aviso(msg, tipo) {
    toast.textContent = msg;
    toast.className = 'visible ' + (tipo || '');
    clearTimeout(temporizador);
    temporizador = setTimeout(function () { toast.className = ''; }, 3500);
  }

  function montar() {
    app.replaceChildren.apply(app, arguments);
    window.scrollTo(0, 0);
  }

  function marca(subtitulo) {
    return h('header', { class: 'marca' },
      h('div', { class: 'logo' }, 'CI'),
      h('h1', {}, 'Comedor Ingenio'),
      subtitulo ? h('p', { class: 'suave' }, subtitulo) : null);
  }

  /* ---------- teclado de PIN ---------- */
  function teclado(o) {
    let pin = '';
    let ocupado = false;
    const puntos = h('div', { class: 'puntos', 'aria-label': 'PIN' });
    const boton = h('button', { class: 'btn primario', disabled: true, onclick: enviar }, o.textoBoton || 'Entrar');

    function pintar() {
      const hijos = [];
      for (let i = 0; i < 6; i++) {
        hijos.push(h('span', { class: 'punto' + (i < pin.length ? ' lleno' : '') }));
      }
      puntos.replaceChildren.apply(puntos, hijos);
      boton.disabled = pin.length < 4 || ocupado;
    }

    async function enviar() {
      if (pin.length < 4 || ocupado) return;
      ocupado = true; pintar();
      boton.textContent = 'Un momento…';
      try { await o.onListo(pin); }
      catch (e) { aviso(e.message, 'error'); pin = ''; }
      ocupado = false;
      boton.textContent = o.textoBoton || 'Entrar';
      pintar();
    }

    function tecla(txt, accion, etiqueta) {
      return h('button', {
        class: 'tecla', type: 'button', 'aria-label': etiqueta || txt,
        onclick: function () { if (!ocupado) accion(); }
      }, txt);
    }
    const num = function (n) {
      return tecla(String(n), function () { if (pin.length < 6) { pin += n; pintar(); } });
    };

    const rejilla = h('div', { class: 'teclado' },
      num(1), num(2), num(3), num(4), num(5), num(6), num(7), num(8), num(9),
      h('span', {}),
      num(0),
      tecla('⌫', function () { pin = pin.slice(0, -1); pintar(); }, 'Borrar'));
    pintar();

    return h('section', { class: 'panel' },
      h('h2', {}, o.titulo),
      o.subtitulo ? h('p', { class: 'suave' }, o.subtitulo) : null,
      puntos, rejilla, boton,
      o.onAtras ? h('button', { class: 'btn texto', onclick: o.onAtras }, 'Volver') : null);
  }

  /* ---------- acceso ---------- */
  async function vistaLogin() {
    usuario = null; pinTemporal = null; document.body.removeAttribute('data-rol');
    montar(marca(), h('p', { class: 'suave centro' }, 'Cargando usuarios…'));
    let lista;
    try { lista = await Api.llamar('auth.lista'); }
    catch (e) {
      montar(marca(), h('p', { class: 'error centro' }, e.message),
        h('button', { class: 'btn', onclick: vistaLogin }, 'Reintentar'));
      return;
    }
    montar(marca('Control del comedor'),
      h('h2', {}, '¿Quién eres?'),
      h('div', { class: 'usuarios' }, lista.map(function (u) {
        return h('button', { class: 'btn usuario', onclick: function () { vistaPin(u.nombre); } }, u.nombre);
      })));
  }

  function vistaPin(nombre) {
    montar(marca(), teclado({
      titulo: 'Hola, ' + nombre,
      subtitulo: 'Escribe tu PIN',
      onAtras: vistaLogin,
      onListo: async function (pin) {
        const r = await Api.llamar('auth.login', {
          nombre: nombre, pin: pin, dispositivo: navigator.userAgent.slice(0, 60)
        });
        Api.guardar({ token: r.token, expira_en: r.expira_en });
        usuario = r.usuario; pinTemporal = pin;
        entrar();
      }
    }));
  }

  function entrar() {
    document.body.setAttribute('data-rol', usuario.rol);
    if (usuario.debe_cambiar_pin) vistaCambiarPin(); else vistaInicio();
  }

  /* ---------- cambio de PIN ---------- */
  function vistaCambiarPin() {
    function pasoNuevo(actual) {
      montar(marca(), teclado({
        titulo: 'Elige tu PIN nuevo',
        subtitulo: 'De 4 a 6 números. Evita 1234 o números repetidos.',
        textoBoton: 'Siguiente',
        onAtras: usuario && !usuario.debe_cambiar_pin ? vistaInicio : null,
        onListo: async function (nuevo) { pasoConfirmar(actual, nuevo); }
      }));
    }
    function pasoConfirmar(actual, nuevo) {
      montar(marca(), teclado({
        titulo: 'Repite tu PIN nuevo',
        textoBoton: 'Guardar',
        onListo: async function (confirmar) {
          if (confirmar !== nuevo) { aviso('No coinciden. Empieza de nuevo.', 'error'); pasoNuevo(actual); return; }
          try {
            await Api.llamar('auth.cambiarPin', { pinActual: actual, pinNuevo: nuevo });
          } catch (e) {
            aviso(e.message, 'error');
            if (e.codigo === 'sesion') { vistaLogin(); return; }
            if (/actual/i.test(e.message)) { pinTemporal = null; vistaCambiarPin(); return; }
            pasoNuevo(actual); return;
          }
          pinTemporal = null; usuario.debe_cambiar_pin = false;
          aviso('PIN cambiado', 'ok');
          vistaInicio();
        }
      }));
    }
    if (pinTemporal) pasoNuevo(pinTemporal);
    else montar(marca(), teclado({
      titulo: 'Escribe tu PIN actual', textoBoton: 'Siguiente',
      onAtras: usuario && !usuario.debe_cambiar_pin ? vistaInicio : null,
      onListo: async function (a) { pasoNuevo(a); }
    }));
  }

  /* ---------- inicio por rol ---------- */
  let modoRegistro = 'ventas';
  const MENUS = {
    socio:     { titulo: 'Socios',    tabs: [['🏠', 'Inicio', 'inicio'], ['🧾', 'Ventas', 'ventas'], ['💵', 'Caja', 'caja'], ['📦', 'Inventario', 'inventario'], ['📊', 'Reportes', 'reportes'], ['⋯', 'Más', 'mas']] },
    encargada: { titulo: 'Encargada', tabs: [['🏠', 'Inicio', 'inicio'], ['✍️', 'Registrar', 'registrar'], ['💵', 'Caja', 'caja'], ['📦', 'Inventario', 'inventario'], ['🛒', 'Pedidos', 'pedidos'], ['⋯', 'Más', 'mas']] }
  };
  let modoReporte = 'produccion';
  let alertasNuevas = 0;

  function tiene(p) { return usuario.permisos.indexOf('*') !== -1 || usuario.permisos.indexOf(p) !== -1; }
  function dinero(n) { return Number(n || 0).toLocaleString('es-MX', { style: 'currency', currency: 'MXN' }); }
  function numero(t) { return Number(String(t).replace(',', '.').replace(/[^\d.]/g, '')); }
  function cargando() { return h('p', { class: 'suave centro' }, 'Cargando…'); }
  function vacio(t) { return h('div', { class: 'vacio' }, h('p', { class: 'suave centro' }, t)); }
  function aInicio() { tabActiva = 0; vistaInicio(); }

  async function cerrarSesion() {
    try { await Api.llamar('auth.logout'); } catch (e) { /* ya no importa */ }
    Api.guardar(null);
    vistaLogin();
  }

  function proximamente(fase) {
    return function () { aviso('Disponible en la Fase ' + fase, ''); };
  }

  function marco(contenido) {
    const menu = MENUS[usuario.rol] || MENUS.encargada;
    montar(h('div', { class: 'inicio' },
      h('header', { class: 'barra' },
        h('div', {}, h('strong', {}, 'Comedor Ingenio'), h('span', { class: 'suave' }, ' · ' + menu.titulo)),
        h('div', { class: 'barra-der' },
          tiene('alertas.ver') ? h('button', { class: 'campana' + (alertasNuevas ? ' con' : ''), 'aria-label': 'Alertas', onclick: panelAlertas },
            '🔔' + (alertasNuevas ? ' ' + alertasNuevas : '')) : null,
          h('span', { class: 'estado' }, '● En línea'))),
      h('div', { class: 'contenido' }, contenido),
      h('nav', { class: 'nav', style: 'grid-template-columns:repeat(' + menu.tabs.length + ',1fr)' }, menu.tabs.map(function (t, i) {
        return h('button', {
          class: 'tab' + (i === tabActiva ? ' activa' : ''),
          onclick: function () { tabActiva = i; vistaInicio(); }
        }, h('span', { class: 'icono' }, t[0]), h('span', {}, t[1]));
      }))));
  }

  function falloVista(e, reintentar) {
    if (e.codigo === 'sesion') { aviso(e.message, 'error'); vistaLogin(); return; }
    marco(h('div', {}, h('p', { class: 'error centro' }, e.message),
      h('button', { class: 'btn', onclick: reintentar }, 'Reintentar')));
  }

  function vistaInicio() {
    if (usuario.rol === 'cocina') { vistaCocina(); return; }
    const menu = MENUS[usuario.rol] || MENUS.encargada;
    const clave = menu.tabs[tabActiva][2];
    const paneles = {
      inicio: panelInicio, ventas: panelVentas, registrar: abrirRegistro, caja: panelCaja, mas: panelMas,
      inventario: panelInventario, reportes: panelReportes, pedidos: function () { panelPedidos(); }
    };
    (paneles[clave] || panelInicio)();
  }

  /* --- inicio --- */
  function bannerTurno(est) {
    if (est.abierto) {
      return h('div', { class: 'banner abierto' }, '🟢 Turno abierto desde las ' + est.desde + ' · Fondo ' + dinero(est.fondo));
    }
    return h('div', { class: 'banner' }, h('span', {}, '⚪ Sin turno abierto'),
      tiene('turnos.operar') ? h('button', { class: 'btn pequeno', onclick: vistaAbrirTurno }, 'Abrir turno') : null);
  }

  function irAPestana(clave) {
    const menu = MENUS[usuario.rol] || MENUS.encargada;
    for (let k = 0; k < menu.tabs.length; k++) if (menu.tabs[k][2] === clave) tabActiva = k;
    vistaInicio();
  }

  function avisoBajos(n) {
    return h('div', { class: 'banner alerta', onclick: function () { irAPestana('inventario'); } },
      '⚠️ ' + n + (n === 1 ? ' insumo bajo el mínimo' : ' insumos bajo el mínimo'));
  }

  async function panelInicio() {
    marco(cargando());
    let est, res, prod, inv;
    try {
      const r = await Promise.all([Api.llamar('turnos.estado'), Api.llamar('resumen.inicio'),
        tiene('produccion.ver') ? Api.llamar('produccion.resumen') : null,
        tiene('inventario.ver') ? Api.llamar('inventario.lista') : null,
        tiene('alertas.ver') ? Api.llamar('alertas.lista') : null]);
      est = r[0]; res = r[1]; prod = r[2]; inv = r[3];
      if (r[4]) alertasNuevas = r[4].nuevas;
    } catch (e) { falloVista(e, panelInicio); return; }
    const colores = ['verde', 'azul', 'naranja', 'morado'];
    marco(h('div', {},
      h('h2', {}, 'Hola, ' + usuario.nombre),
      bannerTurno(est),
      inv && inv.bajos > 0 ? avisoBajos(inv.bajos) : null,
      h('div', { class: 'tarjetas' }, res.tarjetas.map(function (t, i) {
        const v = t.valor == null ? '—' : (t.formato === 'moneda' ? dinero(t.valor) : String(t.valor));
        return h('div', { class: 'tarjeta ' + colores[i % 4] }, h('span', { class: 'suave' }, t.titulo), h('strong', {}, v));
      })),
      prod && prod.turno ? bloqueProduccion(prod, true) : null));
  }

  function vistaAbrirTurno() {
    const fondo = h('input', { class: 'campo', type: 'text', inputmode: 'decimal', placeholder: 'Ej. 500' });
    marco(h('div', {},
      h('h2', {}, 'Abrir turno'),
      h('label', { class: 'suave' }, 'Fondo inicial en caja (pesos)'), fondo,
      h('button', { class: 'btn primario', onclick: async function (ev) {
        const b = ev.currentTarget; b.disabled = true;
        try { await Api.llamar('turnos.abrir', { fondo: numero(fondo.value) }); aviso('Turno abierto', 'ok'); aInicio(); }
        catch (e) { aviso(e.message, 'error'); b.disabled = false; if (e.codigo === 'sesion') vistaLogin(); }
      } }, 'Abrir turno'),
      h('button', { class: 'btn texto', onclick: aInicio }, 'Cancelar')));
  }

  /* --- ventas --- */
  async function nodoRegistroVentas() {
    const r = await Promise.all([Api.llamar('menu.listar'), Api.llamar('turnos.estado')]);
    const menu = r[0], est = r[1];
    if (!est.abierto) return vacio('No hay turno abierto. La encargada debe abrirlo para registrar ventas.');
    if (!menu.length) return vacio('No hay platillos en el menú. Agrégalos en la hoja productos_menu.');
    const cant = {}, contadores = {};
    const total = h('strong', {}, dinero(0));
    const boton = h('button', { class: 'btn primario', disabled: true, onclick: enviar }, 'Registrar venta');

    function suma() { return menu.reduce(function (a, p) { return a + (cant[p.id] || 0) * p.precio; }, 0); }
    function pintar() {
      menu.forEach(function (p) {
        contadores[p.id].textContent = String(cant[p.id] || 0);
        contadores[p.id].closest('.producto').classList.toggle('con', (cant[p.id] || 0) > 0);
      });
      const t = suma(); total.textContent = dinero(t); boton.disabled = t <= 0;
    }
    async function enviar() {
      const lineas = menu.filter(function (p) { return cant[p.id] > 0; })
        .map(function (p) { return { producto_id: p.id, cantidad: cant[p.id] }; });
      boton.disabled = true; boton.textContent = 'Guardando…';
      try {
        const res = await Api.llamar('ventas.registrar', { lineas: lineas });
        menu.forEach(function (p) { cant[p.id] = 0; });
        aviso('Venta registrada · ' + dinero(res.total), 'ok');
      } catch (e) {
        aviso(e.message, 'error');
        if (e.codigo === 'sesion') { vistaLogin(); return; }
      }
      boton.textContent = 'Registrar venta'; pintar();
    }

    const rejilla = h('div', { class: 'productos' }, menu.map(function (p) {
      const c = h('span', { class: 'contador' }, '0');
      contadores[p.id] = c;
      return h('div', { class: 'producto' },
        h('button', { class: 'tile', type: 'button', onclick: function () {
          if ((cant[p.id] || 0) < 99) { cant[p.id] = (cant[p.id] || 0) + 1; pintar(); }
        } }, h('span', { class: 'nombre' }, p.nombre), h('span', { class: 'suave' }, dinero(p.precio))),
        h('div', { class: 'cantidad' },
          h('button', { class: 'menos', type: 'button', 'aria-label': 'Quitar uno', onclick: function () {
            if (cant[p.id] > 0) { cant[p.id]--; pintar(); }
          } }, '−'), c));
    }));
    return h('div', {}, rejilla, h('div', { class: 'total-barra' }, h('span', {}, 'Total'), total), boton);
  }

  function selectorModo() {
    const modos = [['ventas', 'Ventas']];
    if (tiene('produccion.ver')) modos.push(['produccion', 'Producción']);
    if (tiene('checklists.ejecutar')) modos.push(['checklists', 'Checklists']);
    if (modos.length === 1) return h('h2', {}, 'Registrar venta');
    return h('div', { class: 'segmento' + (modos.length === 3 ? ' tres' : '') }, modos.map(function (m) {
      return h('button', { class: 'seg' + (modoRegistro === m[0] ? ' activa' : ''),
        onclick: function () { modoRegistro = m[0]; abrirRegistro(); } }, m[1]);
    }));
  }

  async function abrirRegistro() {
    if (modoRegistro === 'produccion' && tiene('produccion.ver')) { panelProduccion('registro'); return; }
    if (modoRegistro === 'checklists' && tiene('checklists.ejecutar')) { panelChecklists(); return; }
    marco(cargando());
    let nodo;
    try { nodo = await nodoRegistroVentas(); } catch (e) { falloVista(e, abrirRegistro); return; }
    marco(h('div', {}, selectorModo(), nodo,
      tiene('ventas.ver') ? h('button', { class: 'btn texto', onclick: panelVentas }, 'Ver ventas del turno') : null));
  }

  function filaVenta(v) {
    const anulada = v.estado !== 'activa';
    return h('div', { class: 'linea' + (anulada ? ' anulada' : '') },
      h('div', {}, h('strong', {}, v.cantidad + ' × ' + v.producto),
        h('div', { class: 'suave' }, v.hora + ' · ' + v.usuario + (anulada ? ' · ANULADA' : ''))),
      h('div', { class: 'derecha' }, h('strong', {}, dinero(v.total)),
        (!anulada && tiene('ventas.anular')) ? h('button', { class: 'btn pequeno', onclick: async function () {
          const motivo = prompt('Motivo de la anulación:');
          if (!motivo) return;
          try { await Api.llamar('ventas.anular', { id: v.id, motivo: motivo }); aviso('Venta anulada', 'ok'); panelVentas(); }
          catch (e) { aviso(e.message, 'error'); }
        } }, 'Anular') : null));
  }

  async function panelVentas() {
    marco(cargando());
    let d;
    try { d = await Api.llamar('ventas.lista'); } catch (e) { falloVista(e, panelVentas); return; }
    if (!d.turno) { marco(h('div', {}, h('h2', {}, 'Ventas'), vacio('No hay turno abierto.'))); return; }
    marco(h('div', {},
      h('h2', {}, 'Ventas del turno'),
      h('div', { class: 'resumen-linea' }, h('span', {}, d.platillos + ' platillos'), h('strong', {}, dinero(d.total))),
      tiene('ventas.registrar') ? h('button', { class: 'btn primario', onclick: abrirRegistro }, '+ Registrar venta') : null,
      h('div', { class: 'lista' }, d.ventas.length ? d.ventas.map(filaVenta) : vacio('Aún no hay ventas.'))));
  }

  /* --- caja --- */
  function renglon(etiqueta, valor, clase) {
    return h('div', { class: 'renglon' + (clase ? ' ' + clase : '') }, h('span', {}, etiqueta), h('strong', {}, dinero(valor)));
  }

  function bloqueCierre(titulo, c) {
    const color = c.diferencia === 0 ? 'ok' : (Math.abs(c.diferencia) <= 20 ? 'aviso' : 'mal');
    return h('div', { class: 'bloque' }, h('h3', {}, titulo),
      renglon('Esperado', c.esperado), renglon('Contado', c.contado),
      renglon('Diferencia', c.diferencia, color));
  }

  async function panelCaja() {
    marco(cargando());
    let d;
    try { d = await Api.llamar('caja.resumen'); } catch (e) { falloVista(e, panelCaja); return; }
    if (!d.turno) {
      marco(h('div', {}, h('h2', {}, 'Caja'), vacio('No hay turno abierto.'),
        d.ultimoCierre ? bloqueCierre('Último cierre', d.ultimoCierre) : null,
        tiene('turnos.operar') ? h('button', { class: 'btn primario', onclick: vistaAbrirTurno }, 'Abrir turno') : null));
      return;
    }
    marco(h('div', {},
      h('h2', {}, 'Caja del turno'),
      h('div', { class: 'bloque' },
        renglon('Fondo inicial', d.fondo), renglon('Ventas', d.ventas),
        renglon('Ingresos', d.ingresos), renglon('Gastos', d.gastos),
        d.esperado !== undefined ? renglon('Efectivo esperado', d.esperado, 'total') : null),
      h('div', { class: 'acciones' },
        h('button', { class: 'btn', onclick: function () { vistaMovimiento('gasto'); } }, '− Gasto'),
        h('button', { class: 'btn', onclick: function () { vistaMovimiento('ingreso'); } }, '+ Ingreso')),
      tiene('caja.cerrar') ? h('button', { class: 'btn peligro', onclick: vistaCerrarTurno }, 'Cerrar turno') : null,
      h('h3', {}, 'Movimientos'),
      h('div', { class: 'lista' }, d.movimientos.length ? d.movimientos.map(function (m) {
        return h('div', { class: 'linea' },
          h('div', {}, h('strong', {}, m.concepto), h('div', { class: 'suave' }, m.hora + ' · ' + m.tipo)),
          h('div', { class: 'derecha' },
            h('strong', {}, (m.tipo === 'gasto' ? '−' : '+') + dinero(m.monto)),
            h('button', { class: 'btn pequeno', onclick: async function () {
              if (!confirm('¿Anular "' + m.concepto + '"?')) return;
              try { await Api.llamar('caja.anular', { id: m.id }); aviso('Movimiento anulado', 'ok'); panelCaja(); }
              catch (e) { aviso(e.message, 'error'); }
            } }, 'Anular')));
      }) : vacio('Sin movimientos.'))));
  }

  function vistaMovimiento(tipo) {
    const concepto = h('input', { class: 'campo', type: 'text', maxlength: '80', placeholder: tipo === 'gasto' ? 'Ej. Gas, limones, hielo' : 'Ej. Cambio de banco' });
    const monto = h('input', { class: 'campo', type: 'text', inputmode: 'decimal', placeholder: '0.00' });
    marco(h('div', {},
      h('h2', {}, tipo === 'gasto' ? 'Registrar gasto' : 'Registrar ingreso'),
      h('label', { class: 'suave' }, 'Concepto'), concepto,
      h('label', { class: 'suave' }, 'Monto (pesos)'), monto,
      h('button', { class: 'btn primario', onclick: async function (ev) {
        const b = ev.currentTarget; b.disabled = true;
        try {
          await Api.llamar('caja.registrar', { tipo: tipo, concepto: concepto.value, monto: numero(monto.value) });
          aviso('Registrado', 'ok'); panelCaja();
        } catch (e) { aviso(e.message, 'error'); b.disabled = false; if (e.codigo === 'sesion') vistaLogin(); }
      } }, 'Guardar'),
      h('button', { class: 'btn texto', onclick: panelCaja }, 'Cancelar')));
  }

  function vistaCerrarTurno() {
    const contado = h('input', { class: 'campo', type: 'text', inputmode: 'decimal', placeholder: 'Efectivo que hay en caja' });
    const nota = h('input', { class: 'campo', type: 'text', maxlength: '120', placeholder: 'Nota (opcional)' });
    marco(h('div', {},
      h('h2', {}, 'Cerrar turno'),
      h('p', { class: 'suave' }, 'Cuenta el efectivo de la caja y escríbelo. Al guardar verás la diferencia.'),
      h('label', { class: 'suave' }, 'Efectivo contado (pesos)'), contado,
      h('label', { class: 'suave' }, 'Nota'), nota,
      h('button', { class: 'btn peligro', onclick: async function (ev) {
        if (contado.value.trim() === '') { aviso('Escribe el efectivo contado', 'error'); return; }
        if (!confirm('¿Cerrar el turno con ' + dinero(numero(contado.value)) + '? Ya no se podrán registrar ventas.')) return;
        const b = ev.currentTarget; b.disabled = true;
        try {
          const r = await Api.llamar('turnos.cerrar', { contado: numero(contado.value), nota: nota.value });
          vistaResultadoCierre(r);
        } catch (e) { aviso(e.message, 'error'); b.disabled = false; if (e.codigo === 'sesion') vistaLogin(); }
      } }, 'Cerrar turno'),
      h('button', { class: 'btn texto', onclick: panelCaja }, 'Cancelar')));
  }

  function vistaResultadoCierre(r) {
    marco(h('div', {},
      h('h2', {}, 'Turno cerrado'),
      bloqueCierre('Resultado de caja', r),
      h('p', { class: 'suave' }, 'Ventas del turno: ' + dinero(r.ventas) + ' · Gastos: ' + dinero(r.gastos)),
      h('button', { class: 'btn primario', onclick: aInicio }, 'Listo')));
  }

  /* --- más --- */
  function panelMas() {
    marco(h('div', {},
      h('h2', {}, usuario.nombre),
      h('p', { class: 'suave' }, 'Rol: ' + usuario.rol),
      h('button', { class: 'btn', onclick: function () { vistaCambiarPin(); } }, 'Cambiar mi PIN'),
      usuario.es_admin ? h('button', { class: 'btn', onclick: vistaAdmin }, '⚙️ Administrar usuarios') : null,
      h('button', { class: 'btn peligro', onclick: cerrarSesion }, 'Cerrar sesión')));
  }

  /* --- producción (cocina, encargada y socios) --- */
  const TIPOS = {
    corte: { titulo: 'Registrar corte', corto: 'Corte', icono: '🍲', color: 'azul' },
    uso:   { titulo: 'Registrar uso', corto: 'Uso', icono: '🥘', color: 'verde' },
    merma: { titulo: 'Registrar merma', corto: 'Merma', icono: '🗑️', color: 'naranja' }
  };
  function kg(n) { return Number(n || 0).toLocaleString('es-MX', { maximumFractionDigits: 2 }) + ' kg'; }
  function conSigno(n) { return (n > 0 ? '+' : '') + kg(n); }

  function pantalla(titulo, volver, nodo) {
    if (usuario.rol === 'cocina') {
      montar(h('div', { class: 'cocina' },
        h('header', { class: 'barra' }, h('strong', {}, titulo),
          h('button', { class: 'btn pequeno', onclick: volver }, 'Volver')), nodo));
    } else {
      marco(h('div', {}, h('h2', {}, titulo), nodo, h('button', { class: 'btn texto', onclick: volver }, 'Volver')));
    }
  }

  function textoEstado(d) {
    if (d.estado === 'ok') return '✅ Todo en orden (dentro del rango de ±' + kg(d.tolerancia) + ')';
    if (d.estado === 'alerta') return '⚠️ Revisar: la diferencia pasa de ±' + kg(d.tolerancia);
    return 'Aún no hay datos para comparar';
  }

  function bloqueProduccion(d, conTitulo) {
    const clase = d.estado === 'ok' ? 'ok' : (d.estado === 'alerta' ? 'mal' : '');
    const linea = function (e, v) { return h('div', { class: 'renglon' }, h('span', {}, e), h('strong', {}, kg(v))); };
    return h('div', { class: 'bloque' },
      conTitulo ? h('h3', {}, 'Producción del turno') : null,
      linea('Corte (preparado)', d.corte), linea('Uso', d.uso),
      d.ventasKg !== undefined ? linea('Ventas', d.ventasKg) : null,
      d.diferencia !== undefined ? h('div', { class: 'renglon ' + clase }, h('span', {}, 'Diferencia (uso − ventas)'),
        h('strong', {}, conSigno(d.diferencia))) : null,
      linea('Merma', d.merma), linea('Sobrante', d.sobrante),
      d.estado ? h('p', { class: 'suave' }, textoEstado(d)) : null);
  }

  async function flujoProduccion(tipo, volver) {
    pantalla(TIPOS[tipo].titulo, volver, cargando());
    let lista, est;
    try {
      const r = await Promise.all([Api.llamar('produccion.productos'), Api.llamar('turnos.estado')]);
      lista = r[0]; est = r[1];
    } catch (e) {
      aviso(e.message, 'error');
      if (e.codigo === 'sesion') { vistaLogin(); return; }
      volver(); return;
    }
    if (!est.abierto) { pantalla(TIPOS[tipo].titulo, volver, vacio('No hay turno abierto. La encargada debe abrirlo.')); return; }
    if (!lista.length) {
      pantalla(TIPOS[tipo].titulo, volver, vacio('No hay platillos con peso por porción. Llena la columna porcion_kg en productos_menu.'));
      return;
    }
    pantalla(TIPOS[tipo].titulo + ' · ¿cuál platillo?', volver, h('div', { class: 'productos' }, lista.map(function (p) {
      return h('div', { class: 'producto' }, h('button', { class: 'tile', type: 'button',
        onclick: function () { vistaKg(tipo, p, volver); } }, h('span', { class: 'nombre' }, p.nombre)));
    })));
  }

  function vistaKg(tipo, p, volver) {
    let valor = '';
    const pantallaValor = h('div', { class: 'kg-valor' }, '0 kg');
    const guardar = h('button', { class: 'btn primario', disabled: true, onclick: async function () {
      guardar.disabled = true; guardar.textContent = 'Guardando…';
      try {
        const r = await Api.llamar('produccion.registrar', { tipo: tipo, producto_id: p.id, kg: Number(valor) });
        aviso(TIPOS[tipo].corto + ' guardado: ' + kg(r.kg) + (r.inventario === 'sin_receta' ? ' · sin receta, no descontó inventario' : ''), 'ok');
        volver();
      } catch (e) {
        aviso(e.message, 'error');
        if (e.codigo === 'sesion') { vistaLogin(); return; }
        guardar.textContent = 'Guardar'; guardar.disabled = false;
      }
    } }, 'Guardar');
    function pintar() { pantallaValor.textContent = (valor || '0') + ' kg'; guardar.disabled = !(Number(valor) > 0); }
    function tecla(t, f) { return h('button', { class: 'tecla', type: 'button', onclick: f }, t); }
    const num = function (n) {
      return tecla(String(n), function () {
        const i = valor.indexOf('.');
        if (valor.length >= 6 || (i !== -1 && valor.length - i > 2)) return;
        valor = (valor === '0' ? '' : valor) + n; pintar();
      });
    };
    const punto = tecla('.', function () { if (valor.indexOf('.') === -1) { valor = (valor || '0') + '.'; pintar(); } });
    const borrar = tecla('⌫', function () { valor = valor.slice(0, -1); pintar(); });
    pantalla(TIPOS[tipo].titulo + ' · ' + p.nombre, function () { flujoProduccion(tipo, volver); },
      h('div', { class: 'kg' }, pantallaValor,
        h('div', { class: 'teclado' }, num(7), num(8), num(9), num(4), num(5), num(6), num(1), num(2), num(3), punto, num(0), borrar),
        guardar));
  }

  async function panelProduccion(conSelector) {
    marco(cargando());
    let d;
    try { d = await Api.llamar('produccion.resumen'); }
    catch (e) { falloVista(e, function () { panelProduccion(conSelector); }); return; }
    const volver = function () { panelProduccion(conSelector); };
    const encabezado = conSelector === 'registro' ? selectorModo() : (conSelector === 'reporte' ? selectorReporte() : h('h2', {}, 'Producción del turno'));
    if (!d.turno) { marco(h('div', {}, encabezado, vacio('No hay turno abierto.'))); return; }
    marco(h('div', {}, encabezado,
      bloqueProduccion(d, false),
      tiene('produccion.registrar') ? h('div', { class: 'acciones tres' }, ['corte', 'uso', 'merma'].map(function (t) {
        return h('button', { class: 'btn', onclick: function () { flujoProduccion(t, volver); } }, TIPOS[t].icono + ' ' + TIPOS[t].corto);
      })) : null,
      d.platillos.length ? h('h3', {}, 'Por platillo') : null,
      h('div', { class: 'lista' }, d.platillos.map(function (x) {
        const dif = x.diferencia !== undefined ? ' · Vend. ' + kg(x.ventasKg) + ' · Dif. ' + conSigno(x.diferencia) : '';
        return h('div', { class: 'linea' }, h('div', {}, h('strong', {}, x.producto),
          h('div', { class: 'suave' }, 'Corte ' + kg(x.corte) + ' · Uso ' + kg(x.uso) + ' · Merma ' + kg(x.merma) + dif)));
      })),
      d.registros.length ? h('h3', {}, 'Registros') : null,
      h('div', { class: 'lista' }, d.registros.map(function (r) {
        return h('div', { class: 'linea' },
          h('div', {}, h('strong', {}, TIPOS[r.tipo].corto + ' · ' + r.producto),
            h('div', { class: 'suave' }, r.hora + ' · ' + r.usuario)),
          h('div', { class: 'derecha' }, h('strong', {}, kg(r.kg)),
            tiene('produccion.ajustar') ? h('button', { class: 'btn pequeno', onclick: async function () {
              if (!confirm('¿Anular ' + TIPOS[r.tipo].corto.toLowerCase() + ' de ' + kg(r.kg) + '?')) return;
              try { await Api.llamar('produccion.anular', { id: r.id }); aviso('Registro anulado', 'ok'); volver(); }
              catch (e) { aviso(e.message, 'error'); }
            } }, 'Anular') : null));
      }))));
  }

  /* --- inventario --- */
  function cant(n, u) { return Number(n || 0).toLocaleString('es-MX', { maximumFractionDigits: 3 }) + ' ' + u; }

  async function panelInventario() {
    marco(cargando());
    let d;
    try { d = await Api.llamar('inventario.lista'); } catch (e) { falloVista(e, panelInventario); return; }
    marco(h('div', {},
      h('h2', {}, 'Inventario'),
      d.valorTotal !== undefined ? h('div', { class: 'resumen-linea' }, h('span', {}, 'Valor del inventario'), h('strong', {}, dinero(d.valorTotal))) : null,
      d.bajos ? avisoBajos(d.bajos) : null,
      usuario.es_admin ? h('button', { class: 'btn', onclick: vistaNuevoInsumo }, '+ Agregar insumo nuevo') : null,
      h('div', { class: 'lista' }, d.insumos.map(function (i) {
        return h('div', { class: 'fila-usuario' + (i.bajo ? ' bajo' : '') },
          h('div', { class: 'fila-dos' }, h('strong', {}, i.nombre), h('strong', { class: i.bajo ? 'rojo' : '' }, cant(i.existencia, i.unidad))),
          h('div', { class: 'suave' }, 'Mínimo ' + cant(i.minimo, i.unidad) +
            (i.costo !== undefined ? ' · ' + dinero(i.costo) + '/' + i.unidad + ' · valor ' + dinero(i.valor) : '')),
          tiene('inventario.ajustar') ? h('div', { class: 'acciones' },
            h('button', { class: 'btn pequeno', onclick: function () { vistaInvMov(i, 'entrada'); } }, '+ Entrada'),
            h('button', { class: 'btn pequeno', onclick: function () { vistaInvMov(i, 'salida'); } }, '− Salida'),
            h('button', { class: 'btn pequeno', onclick: function () { vistaInvMov(i, 'ajuste'); } }, 'Contar'),
            usuario.es_admin ? h('button', { class: 'btn pequeno', onclick: function () { vistaMinimo(i); } }, 'Mínimo') : null) : null);
      }))));
  }

  function vistaInvMov(i, tipo) {
    const titulos = { entrada: 'Entrada de ', salida: 'Salida de ', ajuste: 'Contar ' };
    const cantidad = h('input', { class: 'campo', type: 'text', inputmode: 'decimal',
      placeholder: tipo === 'ajuste' ? 'Existencia contada (' + i.unidad + ')' : 'Cantidad (' + i.unidad + ')' });
    const nota = h('input', { class: 'campo', type: 'text', maxlength: '120',
      placeholder: tipo === 'entrada' ? 'Nota (opcional)' : 'Motivo (obligatorio)' });
    marco(h('div', {},
      h('h2', {}, titulos[tipo] + i.nombre),
      h('p', { class: 'suave' }, 'Ahora hay ' + cant(i.existencia, i.unidad)),
      h('label', { class: 'suave' }, tipo === 'ajuste' ? 'Existencia contada' : 'Cantidad'), cantidad,
      h('label', { class: 'suave' }, 'Nota'), nota,
      h('button', { class: 'btn primario', onclick: async function (ev) {
        const b = ev.currentTarget;
        if (cantidad.value.trim() === '') { aviso('Escribe la cantidad', 'error'); return; }
        b.disabled = true;
        const datos = { insumo_id: i.id, tipo: tipo, nota: nota.value };
        if (tipo === 'ajuste') datos.existencia_real = numero(cantidad.value); else datos.cantidad = numero(cantidad.value);
        try {
          const r = await Api.llamar('inventario.movimiento', datos);
          aviso('Listo · ahora hay ' + cant(r.existencia, r.unidad), 'ok'); panelInventario();
        } catch (e) { aviso(e.message, 'error'); b.disabled = false; if (e.codigo === 'sesion') vistaLogin(); }
      } }, 'Guardar'),
      h('button', { class: 'btn texto', onclick: panelInventario }, 'Cancelar')));
  }

  /* --- reportes de socios: producción, recetas, pedidos --- */
  function selectorReporte() {
    const modos = [['produccion', 'Producción'], ['recetas', 'Recetas'], ['pedidos', 'Pedidos'], ['checklists', 'Checklists']];
    return h('div', { class: 'segmento cuatro' }, modos.map(function (m) {
      return h('button', { class: 'seg' + (modoReporte === m[0] ? ' activa' : ''),
        onclick: function () { modoReporte = m[0]; panelReportes(); } }, m[1]);
    }));
  }

  function panelReportes() {
    if (modoReporte === 'recetas') panelRecetas();
    else if (modoReporte === 'pedidos') panelPedidos('reporte');
    else if (modoReporte === 'checklists') panelHistorialChecklists('reporte');
    else panelProduccion('reporte');
  }

  async function panelRecetas() {
    marco(cargando());
    let d;
    try { d = await Api.llamar('recetas.lista'); } catch (e) { falloVista(e, panelRecetas); return; }
    marco(h('div', {}, selectorReporte(),
      h('div', { class: 'lista' }, d.length ? d.map(function (r) {
        return h('div', { class: 'bloque' },
          h('strong', {}, r.producto),
          h('div', { class: 'renglon' }, h('span', {}, 'Costo por porción'), h('strong', {}, dinero(r.costoPorcion))),
          h('div', { class: 'renglon' }, h('span', {}, 'Precio de venta'), h('strong', {}, dinero(r.precio))),
          h('div', { class: 'renglon ' + (r.margen >= 0 ? 'ok' : 'mal') }, h('span', {}, 'Margen'),
            h('strong', {}, dinero(r.margen) + ' (' + r.margenPct + '%)')),
          h('p', { class: 'suave' }, 'Rinde ' + r.rendimiento + ' porciones · ' +
            r.ingredientes.map(function (x) { return cant(x.cantidad, x.unidad) + ' ' + x.insumo; }).join(', ')));
      }) : vacio('No hay recetas. Se capturan en las hojas recetas y receta_ingredientes.'))));
  }

  /* --- administración de insumos (solo el administrador) --- */
  const UNIDADES = ['kg', 'g', 'l', 'ml', 'pieza', 'paquete', 'caja', 'bolsa'];

  function vistaMinimo(i) {
    const minimo = h('input', { class: 'campo', type: 'text', inputmode: 'decimal', value: String(i.minimo) });
    marco(h('div', {},
      h('h2', {}, 'Mínimo de ' + i.nombre),
      h('p', { class: 'suave' }, 'Ahora hay ' + cant(i.existencia, i.unidad) + ' y el mínimo es ' + cant(i.minimo, i.unidad) +
        '. Cuando la existencia llegue al mínimo, se avisa.'),
      h('label', { class: 'suave' }, 'Nuevo mínimo (' + i.unidad + ')'), minimo,
      h('button', { class: 'btn primario', onclick: async function (ev) {
        const b = ev.currentTarget;
        if (minimo.value.trim() === '') { aviso('Escribe el mínimo', 'error'); return; }
        b.disabled = true;
        try { await Api.llamar('insumos.minimo', { id: i.id, minimo: numero(minimo.value) }); aviso('Mínimo actualizado', 'ok'); panelInventario(); }
        catch (e) { aviso(e.message, 'error'); b.disabled = false; if (e.codigo === 'sesion') vistaLogin(); }
      } }, 'Guardar'),
      h('button', { class: 'btn texto', onclick: panelInventario }, 'Cancelar')));
  }

  function vistaNuevoInsumo() {
    const nombre = h('input', { class: 'campo', type: 'text', maxlength: '40', placeholder: 'Ej. Chile jalapeño', autocomplete: 'off' });
    const unidad = h('select', { class: 'campo' }, UNIDADES.map(function (u) { return h('option', { value: u }, u); }));
    const costo = h('input', { class: 'campo', type: 'text', inputmode: 'decimal', placeholder: 'Costo por unidad (pesos)' });
    const minimo = h('input', { class: 'campo', type: 'text', inputmode: 'decimal', placeholder: 'Mínimo antes de avisar' });
    const existencia = h('input', { class: 'campo', type: 'text', inputmode: 'decimal', placeholder: 'Cuánto hay ahora (puede ser 0)' });
    marco(h('div', {},
      h('h2', {}, 'Insumo nuevo'),
      h('label', { class: 'suave' }, 'Nombre'), nombre,
      h('label', { class: 'suave' }, 'Unidad'), unidad,
      h('label', { class: 'suave' }, 'Costo por unidad'), costo,
      h('label', { class: 'suave' }, 'Mínimo'), minimo,
      h('label', { class: 'suave' }, 'Existencia inicial'), existencia,
      h('button', { class: 'btn primario', onclick: async function (ev) {
        const b = ev.currentTarget; b.disabled = true;
        try {
          await Api.llamar('insumos.crear', { nombre: nombre.value, unidad: unidad.value, costo: numero(costo.value),
            minimo: numero(minimo.value), existencia: numero(existencia.value) });
          aviso('Insumo agregado', 'ok'); panelInventario();
        } catch (e) { aviso(e.message, 'error'); b.disabled = false; if (e.codigo === 'sesion') vistaLogin(); }
      } }, 'Agregar al inventario'),
      h('button', { class: 'btn texto', onclick: panelInventario }, 'Cancelar')));
  }

  /* --- alertas --- */
  const ICONO_SEV = { alta: '🔴', media: '🟠', baja: '🔵' };

  async function panelAlertas() {
    marco(cargando());
    let d;
    try { d = await Api.llamar('alertas.lista'); } catch (e) { falloVista(e, panelAlertas); return; }
    alertasNuevas = d.nuevas;
    marco(h('div', {},
      h('h2', {}, 'Alertas'),
      d.nuevas ? h('button', { class: 'btn', onclick: async function () {
        try { await Api.llamar('alertas.marcar', { todas: true }); } catch (e) { aviso(e.message, 'error'); }
        panelAlertas();
      } }, 'Marcar todas como vistas') : null,
      h('div', { class: 'lista' }, d.alertas.length ? d.alertas.map(function (a) {
        return h('div', { class: 'fila-usuario' + (a.estado === 'nueva' ? ' nueva' : '') + (a.estado === 'resuelta' ? ' resuelta' : '') },
          h('div', { class: 'fila-dos' }, h('strong', {}, (ICONO_SEV[a.severidad] || '') + ' ' + a.hora), h('span', { class: 'suave' }, a.fecha)),
          h('div', {}, a.mensaje),
          a.estado !== 'resuelta' ? h('button', { class: 'btn pequeno', onclick: async function () {
            try { await Api.llamar('alertas.marcar', { id: a.id, estado: 'resuelta' }); panelAlertas(); }
            catch (e) { aviso(e.message, 'error'); }
          } }, 'Marcar resuelta') : null);
      }) : vacio('Sin alertas. Todo en orden.'))));
  }

  /* --- checklists --- */
  function nodoPlantillas(lista, volver) {
    return h('div', { class: 'lista' }, lista.length ? lista.map(function (p) {
      return h('div', { class: 'fila-usuario' },
        h('div', { class: 'fila-dos' }, h('strong', {}, p.nombre),
          h('span', { class: 'insignia ' + (p.hecha ? 'verde' : 'naranja') }, p.hecha ? 'Hecho' : 'Pendiente')),
        h('div', { class: 'suave' }, p.items.length + ' puntos' + (p.obligatoria_cierre ? ' · obligatorio para cerrar el turno' : '')),
        h('button', { class: 'btn pequeno', onclick: function () { vistaEjecutarChecklist(p, volver); } }, p.hecha ? 'Hacer de nuevo' : 'Empezar'));
    }) : vacio('No hay checklists.'));
  }

  async function panelChecklists() {
    marco(cargando());
    let d;
    try { d = await Api.llamar('checklists.plantillas'); } catch (e) { falloVista(e, panelChecklists); return; }
    marco(h('div', {}, selectorModo(), nodoPlantillas(d, panelChecklists),
      tiene('checklists.revisar') ? h('button', { class: 'btn texto', onclick: function () { panelHistorialChecklists('registro'); } }, 'Ver historial y revisar') : null));
  }

  function vistaEjecutarChecklist(p, volver) {
    const valores = {};
    const controles = p.items.map(function (it) {
      let control;
      if (it.tipo_item === 'si_no') {
        const si = h('button', { class: 'opt', type: 'button' }, 'Sí');
        const no = h('button', { class: 'opt', type: 'button' }, 'No');
        const poner = function (v) {
          valores[it.id] = v;
          si.classList.toggle('activa', v === 'si');
          no.classList.toggle('activa', v === 'no');
        };
        si.addEventListener('click', function () { poner('si'); });
        no.addEventListener('click', function () { poner('no'); });
        control = h('div', { class: 'si-no' }, si, no);
      } else {
        const campo = h('input', { class: 'campo', type: 'text', maxlength: '120',
          inputmode: it.tipo_item === 'numero' ? 'decimal' : 'text', placeholder: it.tipo_item === 'numero' ? 'Número' : 'Escribe aquí' });
        campo.addEventListener('input', function () { valores[it.id] = campo.value; });
        control = campo;
      }
      const rango = it.tipo_item === 'numero' && (it.min !== null || it.max !== null)
        ? ' (' + (it.min !== null ? it.min : '…') + ' a ' + (it.max !== null ? it.max : '…') + ')' : '';
      return h('div', { class: 'item' }, h('div', {}, it.texto + rango + (it.obligatorio ? ' *' : '')), control);
    });
    const obs = h('input', { class: 'campo', type: 'text', maxlength: '120', placeholder: 'Observaciones (opcional)' });
    pantalla(p.nombre, volver, h('div', {}, h('div', { class: 'lista' }, controles), obs,
      h('button', { class: 'btn primario', onclick: async function (ev) {
        const b = ev.currentTarget;
        const falta = p.items.filter(function (it) {
          return it.obligatorio && (valores[it.id] === undefined || String(valores[it.id]).trim() === '');
        })[0];
        if (falta) { aviso('Falta responder: ' + falta.texto, 'error'); return; }
        b.disabled = true; b.textContent = 'Guardando…';
        try {
          const r = await Api.llamar('checklists.ejecutar', { plantilla_id: p.id, observaciones: obs.value,
            respuestas: p.items.map(function (it) { return { item_id: it.id, valor: valores[it.id] === undefined ? '' : valores[it.id] }; }) });
          aviso(r.observaciones ? 'Guardado · se avisó de ' + r.observaciones + ' punto(s) a revisar' : 'Checklist guardado', r.observaciones ? '' : 'ok');
          volver();
        } catch (e) { aviso(e.message, 'error'); b.disabled = false; b.textContent = 'Terminar'; if (e.codigo === 'sesion') vistaLogin(); }
      } }, 'Terminar')));
  }

  async function panelHistorialChecklists(origen) {
    marco(cargando());
    let d;
    try { d = await Api.llamar('checklists.historial'); }
    catch (e) { falloVista(e, function () { panelHistorialChecklists(origen); }); return; }
    marco(h('div', {}, origen === 'reporte' ? selectorReporte() : h('h2', {}, 'Historial de checklists'),
      h('div', { class: 'lista' }, d.length ? d.map(function (e) {
        return h('div', { class: 'fila-usuario' },
          h('div', { class: 'fila-dos' }, h('strong', {}, e.plantilla),
            h('span', { class: 'insignia ' + (e.observaciones ? 'naranja' : 'verde') }, e.observaciones ? 'Con observaciones' : 'Sin observaciones')),
          h('div', { class: 'suave' }, e.fecha + ' ' + e.hora + ' · ' + e.usuario + (e.revisado ? ' · revisado por ' + e.revisado_por : '')),
          h('button', { class: 'btn pequeno', onclick: function () {
            vistaDetalleChecklist(e.id, function () { panelHistorialChecklists(origen); });
          } }, 'Ver detalle'));
      }) : vacio('Aún no hay checklists.')),
      origen === 'registro' ? h('button', { class: 'btn texto', onclick: panelChecklists }, 'Volver') : null));
  }

  async function vistaDetalleChecklist(id, volver) {
    marco(cargando());
    let d;
    try { d = await Api.llamar('checklists.detalle', { id: id }); } catch (e) { falloVista(e, volver); return; }
    marco(h('div', {},
      h('h2', {}, d.plantilla),
      h('p', { class: 'suave' }, d.fecha + ' ' + d.hora + ' · ' + d.usuario),
      h('div', { class: 'bloque' }, d.respuestas.map(function (r) {
        return h('div', { class: 'renglon' + (r.fuera ? ' mal' : '') }, h('span', {}, r.texto), h('strong', {}, r.valor));
      })),
      d.revisado ? h('p', { class: 'suave' }, 'Revisado por ' + d.revisado_por + (d.nota ? ' · ' + d.nota : ''))
        : (tiene('checklists.revisar') ? h('button', { class: 'btn primario', onclick: async function () {
          const n = prompt('Nota de revisión (opcional):');
          if (n === null) return;
          try { await Api.llamar('checklists.revisar', { id: id, nota: n }); aviso('Marcado como revisado', 'ok'); vistaDetalleChecklist(id, volver); }
          catch (e) { aviso(e.message, 'error'); }
        } }, 'Marcar como revisado') : null),
      h('button', { class: 'btn texto', onclick: volver }, 'Volver')));
  }

  /* --- pedidos internos --- */
  const ESTADOS = { pendiente: ['Pendiente', 'naranja'], aprobado: ['Aprobado', 'azul'], recibido: ['Recibido', 'verde'], rechazado: ['Rechazado', 'rojo'] };

  function tarjetaPedido(p, recargar, soloVer) {
    const e = ESTADOS[p.estado] || [p.estado, ''];
    const puede = !soloVer && tiene('pedidos.aprobar');
    return h('div', { class: 'fila-usuario' },
      h('div', { class: 'fila-dos' }, h('strong', {}, p.solicitante + ' · ' + p.hora), h('span', { class: 'insignia ' + e[1] }, e[0])),
      h('div', { class: 'suave' }, p.lineas.map(function (l) {
        const a = l.aprobada !== null && l.aprobada !== l.solicitada ? ' (aprobado ' + cant(l.aprobada, l.unidad) + ')' : '';
        return cant(l.solicitada, l.unidad) + ' ' + l.insumo + a;
      }).join(' · ')),
      p.nota ? h('div', { class: 'suave' }, 'Nota: ' + p.nota) : null,
      p.estado === 'rechazado' && p.motivo ? h('div', { class: 'error' }, 'Motivo: ' + p.motivo) : null,
      puede && p.estado === 'pendiente' ? h('button', { class: 'btn pequeno', onclick: function () { vistaPedido(p, recargar); } }, 'Revisar') : null,
      puede && p.estado === 'aprobado' ? h('button', { class: 'btn pequeno', onclick: async function () {
        if (!confirm('¿Marcar como recibido? Se sumará al inventario.')) return;
        try { await Api.llamar('pedidos.recibir', { id: p.id }); aviso('Entradas registradas en el inventario', 'ok'); recargar(); }
        catch (er) { aviso(er.message, 'error'); }
      } }, 'Marcar recibido') : null);
  }

  async function panelPedidos(modo) {
    marco(cargando());
    let d;
    try { d = await Api.llamar('pedidos.lista'); } catch (e) { falloVista(e, function () { panelPedidos(modo); }); return; }
    const recargar = function () { panelPedidos(modo); };
    marco(h('div', {},
      modo === 'reporte' ? selectorReporte() : h('h2', {}, 'Pedidos internos'),
      h('div', { class: 'resumen-linea' }, h('span', {}, d.pendientes + ' por resolver · ' + d.porRecibir + ' por recibir')),
      h('div', { class: 'lista' }, d.pedidos.length ? d.pedidos.map(function (p) { return tarjetaPedido(p, recargar); }) : vacio('No hay pedidos.'))));
  }

  function vistaPedido(p, recargar) {
    const campos = p.lineas.map(function (l) {
      return h('input', { class: 'campo corto', type: 'text', inputmode: 'decimal', value: String(l.solicitada) });
    });
    marco(h('div', {},
      h('h2', {}, 'Pedido de ' + p.solicitante),
      p.nota ? h('p', { class: 'suave' }, 'Nota: ' + p.nota) : null,
      h('p', { class: 'suave' }, 'Puedes cambiar las cantidades antes de aprobar.'),
      h('div', { class: 'lista' }, p.lineas.map(function (l, k) {
        return h('div', { class: 'linea' },
          h('div', {}, h('strong', {}, l.insumo), h('div', { class: 'suave' }, 'Pidió ' + cant(l.solicitada, l.unidad))),
          h('div', { class: 'derecha' }, campos[k], h('span', { class: 'suave' }, l.unidad)));
      })),
      h('button', { class: 'btn primario', onclick: async function (ev) {
        const b = ev.currentTarget; b.disabled = true;
        try {
          await Api.llamar('pedidos.resolver', { id: p.id, decision: 'aprobar',
            lineas: p.lineas.map(function (l, k) { return { detalle_id: l.id, cantidad: numero(campos[k].value) }; }) });
          aviso('Pedido aprobado', 'ok'); recargar();
        } catch (e) { aviso(e.message, 'error'); b.disabled = false; }
      } }, 'Aprobar'),
      h('button', { class: 'btn peligro', onclick: async function () {
        const m = prompt('Motivo del rechazo:');
        if (!m) return;
        try { await Api.llamar('pedidos.resolver', { id: p.id, decision: 'rechazar', motivo: m }); aviso('Pedido rechazado', 'ok'); recargar(); }
        catch (e) { aviso(e.message, 'error'); }
      } }, 'Rechazar'),
      h('button', { class: 'btn texto', onclick: recargar }, 'Volver')));
  }

  /* --- cocina --- */
  async function vistaVentaCocina() {
    const cabecera = h('header', { class: 'barra' }, h('strong', {}, 'Registrar ventas'),
      h('button', { class: 'btn pequeno', onclick: vistaCocina }, 'Volver'));
    montar(h('div', { class: 'cocina' }, cabecera, cargando()));
    let nodo;
    try { nodo = await nodoRegistroVentas(); }
    catch (e) { aviso(e.message, 'error'); if (e.codigo === 'sesion') { vistaLogin(); return; } vistaCocina(); return; }
    montar(h('div', { class: 'cocina' }, cabecera, nodo));
  }

  async function vistaPedirInsumos() {
    const cabecera = h('header', { class: 'barra' }, h('strong', {}, 'Pedir insumos'),
      h('button', { class: 'btn pequeno', onclick: vistaCocina }, 'Volver'));
    montar(h('div', { class: 'cocina' }, cabecera, cargando()));
    let cat;
    try { cat = await Api.llamar('pedidos.catalogo'); }
    catch (e) { aviso(e.message, 'error'); if (e.codigo === 'sesion') { vistaLogin(); return; } vistaCocina(); return; }
    const cantidades = {}, contadores = {};
    const boton = h('button', { class: 'btn primario', disabled: true, onclick: enviar }, 'Enviar pedido');
    function pintar() {
      let n = 0;
      cat.forEach(function (i) {
        const c = cantidades[i.id] || 0;
        if (c > 0) n++;
        contadores[i.id].textContent = c + ' ' + i.unidad;
        contadores[i.id].closest('.producto').classList.toggle('con', c > 0);
      });
      boton.disabled = n === 0;
      boton.textContent = n ? 'Enviar pedido (' + n + ')' : 'Enviar pedido';
    }
    async function enviar() {
      const lineas = cat.filter(function (i) { return cantidades[i.id] > 0; })
        .map(function (i) { return { insumo_id: i.id, cantidad: cantidades[i.id] }; });
      boton.disabled = true; boton.textContent = 'Enviando…';
      try { await Api.llamar('pedidos.crear', { lineas: lineas }); aviso('Pedido enviado a la encargada', 'ok'); vistaCocina(); }
      catch (e) { aviso(e.message, 'error'); if (e.codigo === 'sesion') { vistaLogin(); return; } pintar(); }
    }
    const rejilla = h('div', { class: 'productos' }, cat.map(function (i) {
      const c = h('span', { class: 'contador' }, '0 ' + i.unidad);
      contadores[i.id] = c;
      return h('div', { class: 'producto' },
        h('button', { class: 'tile', type: 'button', onclick: function () {
          if ((cantidades[i.id] || 0) < 999) { cantidades[i.id] = (cantidades[i.id] || 0) + 1; pintar(); }
        } }, h('span', { class: 'nombre' }, i.nombre), h('span', { class: 'suave' }, 'Toca para sumar 1 ' + i.unidad)),
        h('div', { class: 'cantidad' },
          h('button', { class: 'menos', type: 'button', 'aria-label': 'Quitar uno', onclick: function () {
            if (cantidades[i.id] > 0) { cantidades[i.id]--; pintar(); }
          } }, '−'), c));
    }));
    montar(h('div', { class: 'cocina' }, cabecera, h('div', {}, rejilla, boton)));
  }

  async function vistaPedidosCocina() {
    const cabecera = h('header', { class: 'barra' }, h('strong', {}, 'Mis pedidos'),
      h('button', { class: 'btn pequeno', onclick: vistaCocina }, 'Volver'));
    montar(h('div', { class: 'cocina' }, cabecera, cargando()));
    let d;
    try { d = await Api.llamar('pedidos.lista'); }
    catch (e) { aviso(e.message, 'error'); if (e.codigo === 'sesion') { vistaLogin(); return; } vistaCocina(); return; }
    montar(h('div', { class: 'cocina' }, cabecera,
      h('div', { class: 'lista' }, d.pedidos.length ? d.pedidos.map(function (p) { return tarjetaPedido(p, vistaPedidosCocina, true); }) : vacio('No hay pedidos.'))));
  }

  async function vistaChecklistsCocina() {
    const cabecera = h('header', { class: 'barra' }, h('strong', {}, 'Checklists'),
      h('button', { class: 'btn pequeno', onclick: vistaCocina }, 'Volver'));
    montar(h('div', { class: 'cocina' }, cabecera, cargando()));
    let d;
    try { d = await Api.llamar('checklists.plantillas'); }
    catch (e) { aviso(e.message, 'error'); if (e.codigo === 'sesion') { vistaLogin(); return; } vistaCocina(); return; }
    montar(h('div', { class: 'cocina' }, cabecera, nodoPlantillas(d, vistaChecklistsCocina)));
  }

  async function vistaCocina() {
    const cabecera = h('header', { class: 'barra' },
      h('strong', {}, 'Comedor Ingenio'),
      h('span', { class: 'estado' }, '● En operación'),
      h('button', { class: 'btn pequeno', onclick: cerrarSesion }, 'Salir'));
    montar(h('div', { class: 'cocina' }, cabecera, cargando()));
    let d = null, ped = null;
    try {
      const r = await Promise.all([Api.llamar('produccion.resumen'),
        Api.llamar('pedidos.lista').catch(function () { return null; })]);
      d = r[0]; ped = r[1];
    } catch (e) {
      if (e.codigo === 'sesion') { aviso(e.message, 'error'); vistaLogin(); return; }
      aviso(e.message, 'error');
    }
    const grande = function (txt, icono, color, accion) {
      return h('button', { class: 'grande ' + color, onclick: accion },
        h('span', { class: 'icono' }, icono), h('span', {}, txt));
    };
    const stat = function (t, v, color) {
      return h('div', { class: 'stat ' + color }, h('span', { class: 'suave' }, t), h('strong', {}, kg(v)));
    };
    let resumen;
    if (d && d.turno) {
      resumen = h('div', {},
        h('div', { class: 'stats' }, stat('Corte del día', d.corte, 'azul'), stat('Uso del día', d.uso, 'verde'),
          d.ventasKg !== undefined ? stat('Ventas del día', d.ventasKg, 'morado') : stat('Merma', d.merma, 'naranja')),
        d.diferencia !== undefined ? h('div', { class: 'dif ' + (d.estado === 'alerta' ? 'mal' : 'ok') },
          h('span', {}, 'Diferencia'), h('strong', {}, conSigno(d.diferencia)),
          h('span', {}, d.estado === 'alerta' ? '⚠️ Revisar' : (d.estado === 'ok' ? '✅ Todo en orden' : 'Sin datos'))) : null);
    } else {
      resumen = h('div', { class: 'dif' }, h('span', {}, d ? 'Turno cerrado. La encargada debe abrirlo para registrar.' : 'Sin conexión.'));
    }
    montar(h('div', { class: 'cocina' }, cabecera, resumen,
      h('div', { class: 'botonera' },
        grande('Registrar corte', '🍲', 'azul', function () { flujoProduccion('corte', vistaCocina); }),
        grande('Registrar uso', '🥘', 'verde', function () { flujoProduccion('uso', vistaCocina); }),
        grande('Registrar merma', '🗑️', 'naranja', function () { flujoProduccion('merma', vistaCocina); }),
        grande('Registrar ventas', '🧾', 'morado', vistaVentaCocina)),
      h('footer', { class: 'pie' }, 'Hola, ' + usuario.nombre + ' · ',
        h('button', { class: 'btn texto en-linea', onclick: vistaPedirInsumos }, 'Pedir insumos'), ' · ',
        h('button', { class: 'btn texto en-linea', onclick: vistaPedidosCocina },
          'Pendientes: ' + (ped ? ped.pendientes + ped.porRecibir : 0)), ' · ',
        h('button', { class: 'btn texto en-linea', onclick: vistaChecklistsCocina }, 'Checklists'))));
  }

  /* ---------- administración (solo socios con permiso de administrador) ---------- */
  function errorAdmin(e) {
    aviso(e.message, 'error');
    if (e.codigo === 'sesion') vistaLogin(); else vistaInicio();
  }

  async function vistaAdmin() {
    montar(marca('Administración'), h('p', { class: 'suave centro' }, 'Cargando…'));
    let lista;
    try { lista = await Api.llamar('usuarios.listar'); }
    catch (e) { errorAdmin(e); return; }
    montar(
      h('header', { class: 'barra' },
        h('strong', {}, 'Usuarios'),
        h('button', { class: 'btn pequeno', onclick: function () { tabActiva = 0; vistaInicio(); } }, 'Volver')),
      h('div', { class: 'lista' }, lista.map(tarjetaUsuario)),
      h('button', { class: 'btn primario', onclick: vistaNuevoUsuario }, '+ Nuevo usuario'),
      h('button', { class: 'btn', onclick: vistaAuditoria }, 'Ver actividad reciente'));
  }

  function tarjetaUsuario(u) {
    const insignias = [];
    if (u.es_admin) insignias.push(h('span', { class: 'insignia azul' }, 'Administrador'));
    if (!u.activo) insignias.push(h('span', { class: 'insignia rojo' }, 'Inactivo'));
    if (u.bloqueado) insignias.push(h('span', { class: 'insignia rojo' }, 'Bloqueado'));
    if (u.debe_cambiar_pin) insignias.push(h('span', { class: 'insignia naranja' }, 'PIN pendiente'));
    const esYo = u.id === usuario.id;
    return h('div', { class: 'fila-usuario' },
      h('div', {}, h('strong', {}, u.nombre), h('span', { class: 'suave' }, ' · ' + u.rol + (esYo ? ' (tú)' : ''))),
      h('div', { class: 'insignias' }, insignias),
      esYo ? null : h('div', { class: 'acciones' },
        h('button', { class: 'btn pequeno', onclick: async function () {
          if (!confirm('¿Restablecer el PIN de ' + u.nombre + '? Se cerrará su sesión.')) return;
          try {
            const r = await Api.llamar('usuarios.restablecerPin', { id: u.id });
            vistaPinTemporal(r.nombre, r.pinTemporal);
          } catch (e) { aviso(e.message, 'error'); }
        } }, 'Restablecer PIN'),
        h('button', { class: 'btn pequeno', onclick: async function () {
          const nuevo = !u.activo;
          if (!confirm('¿' + (nuevo ? 'Activar' : 'Desactivar') + ' a ' + u.nombre + '?')) return;
          try { await Api.llamar('usuarios.activar', { id: u.id, activo: nuevo }); vistaAdmin(); }
          catch (e) { aviso(e.message, 'error'); }
        } }, u.activo ? 'Desactivar' : 'Activar')));
  }

  function vistaNuevoUsuario() {
    const nombre = h('input', { class: 'campo', type: 'text', maxlength: '40', placeholder: 'Nombre', autocomplete: 'off' });
    const rol = h('select', { class: 'campo' },
      h('option', { value: 'cocina' }, 'Cocina'),
      h('option', { value: 'encargada' }, 'Encargada'),
      h('option', { value: 'socio' }, 'Socio'));
    montar(marca('Nuevo usuario'),
      h('label', { class: 'suave' }, 'Nombre'), nombre,
      h('label', { class: 'suave' }, 'Rol'), rol,
      h('button', { class: 'btn primario', onclick: async function (ev) {
        const b = ev.currentTarget; b.disabled = true;
        try {
          const r = await Api.llamar('usuarios.crear', { nombre: nombre.value, rol: rol.value });
          vistaPinTemporal(r.nombre, r.pinTemporal);
        } catch (e) { aviso(e.message, 'error'); b.disabled = false; }
      } }, 'Crear usuario'),
      h('button', { class: 'btn texto', onclick: vistaAdmin }, 'Cancelar'));
  }

  function vistaPinTemporal(nombre, pin) {
    montar(marca('PIN temporal'),
      h('section', { class: 'panel' },
        h('h2', {}, nombre),
        h('div', { class: 'pin-grande' }, pin),
        h('p', { class: 'suave' }, 'Entrégalo en persona. Se muestra una sola vez y deberá cambiarlo al entrar.'),
        h('button', { class: 'btn primario', onclick: vistaAdmin }, 'Listo')));
  }

  async function vistaAuditoria() {
    montar(marca('Actividad reciente'), h('p', { class: 'suave centro' }, 'Cargando…'));
    let filas;
    try { filas = await Api.llamar('auditoria.recientes'); }
    catch (e) { errorAdmin(e); return; }
    montar(
      h('header', { class: 'barra' },
        h('strong', {}, 'Actividad'),
        h('button', { class: 'btn pequeno', onclick: vistaAdmin }, 'Volver')),
      h('div', { class: 'lista' }, filas.length ? filas.map(function (f) {
        return h('div', { class: 'registro' },
          h('span', { class: 'suave' }, f.fecha + ' ' + f.hora),
          h('span', {}, f.usuario + ' · ' + f.accion + (f.detalle ? ' · ' + f.detalle : '')));
      }) : h('p', { class: 'suave centro' }, 'Sin registros.')));
  }

  /* ---------- arranque ---------- */
  async function iniciar() {
    if (!window.CONFIG || !CONFIG.API_URL || CONFIG.API_URL.indexOf('PEGA') !== -1) {
      montar(marca(), h('p', { class: 'error centro' }, 'Falta configurar la dirección de la API (config.js).'));
      return;
    }
    if (!Api.hayToken()) { vistaLogin(); return; }
    montar(marca(), h('p', { class: 'suave centro' }, 'Abriendo tu sesión…'));
    try { usuario = await Api.llamar('auth.yo'); entrar(); }
    catch (e) {
      if (e.codigo === 'red') {
        montar(marca(), h('p', { class: 'error centro' }, e.message),
          h('button', { class: 'btn', onclick: iniciar }, 'Reintentar'));
      } else { vistaLogin(); }
    }
  }

  iniciar();
})();
