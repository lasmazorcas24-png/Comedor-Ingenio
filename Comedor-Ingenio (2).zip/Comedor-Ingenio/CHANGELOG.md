# Historial de cambios

## [Sin publicar]
### Agregado
- v0.2.0: panel de administración (crear usuarios, restablecer PIN, activar/desactivar, actividad reciente) para socios con `es_admin`, y funciones de recuperación de acceso desde el editor.
- Fase 1 · pieza 3: pantalla de acceso (selección de usuario, teclado de PIN, cambio obligatorio de PIN) e inicio provisional por rol (socios, encargada, cocina). PWA instalable (manifest e íconos).
- Fase 1 · pieza 2: API de login con sesiones, bloqueo por intentos, permisos por rol y auditoría (`backend/apps-script/Codigo.gs`, `docs/modulos/auth.md`).
- Fase 1 · pieza 1: hojas de seguridad en Google Sheets (usuarios, roles_permisos, sesiones, dispositivos, config, auditoria).
- Fase 0: estructura del repositorio, arquitectura, módulos, permisos, plan por fases y ADR-001 a ADR-006.
